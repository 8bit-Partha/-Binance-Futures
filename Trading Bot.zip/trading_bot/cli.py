#!/usr/bin/env python3
"""
Trading Bot CLI — Binance Futures Testnet (USDT-M)

Usage examples:
  # Market BUY
  python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

  # Limit SELL
  python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 95000

  # Stop-Market SELL (bonus order type)
  python cli.py --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --stop-price 90000

  # Override API credentials inline (not recommended; prefer env vars)
  python cli.py --api-key KEY --api-secret SECRET ...

API keys are read from environment variables by default:
  BINANCE_API_KEY
  BINANCE_API_SECRET
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from bot.client import BinanceAPIError, BinanceClient
from bot.logging_config import get_logger, setup_logging
from bot.orders import place_order
from bot.validators import validate_order_params

# ── ANSI colours (gracefully disabled on Windows without color support) ──────
try:
    import colorama  # type: ignore

    colorama.init(autoreset=True)
    GREEN = colorama.Fore.GREEN
    RED = colorama.Fore.RED
    CYAN = colorama.Fore.CYAN
    YELLOW = colorama.Fore.YELLOW
    BOLD = colorama.Style.BRIGHT
    RESET = colorama.Style.RESET_ALL
except ImportError:
    GREEN = RED = CYAN = YELLOW = BOLD = RESET = ""


def _print_section(title: str, data: dict) -> None:
    """Pretty-print a labeled key-value section."""
    print(f"\n{BOLD}{CYAN}{'─' * 50}{RESET}")
    print(f"{BOLD}{CYAN}  {title}{RESET}")
    print(f"{BOLD}{CYAN}{'─' * 50}{RESET}")
    for key, value in data.items():
        if value is not None:
            print(f"  {YELLOW}{key:<18}{RESET} {value}")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Place orders on Binance Futures Testnet (USDT-M)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # ── Credentials ────────────────────────────────────────────────────
    creds = parser.add_argument_group("API credentials (env vars preferred)")
    creds.add_argument(
        "--api-key",
        default=os.environ.get("BINANCE_API_KEY", ""),
        help="Binance API key (default: $BINANCE_API_KEY)",
    )
    creds.add_argument(
        "--api-secret",
        default=os.environ.get("BINANCE_API_SECRET", ""),
        help="Binance API secret (default: $BINANCE_API_SECRET)",
    )

    # ── Order parameters ────────────────────────────────────────────────
    order = parser.add_argument_group("order parameters")
    order.add_argument(
        "--symbol",
        required=True,
        metavar="SYMBOL",
        help="Trading pair, e.g. BTCUSDT",
    )
    order.add_argument(
        "--side",
        required=True,
        choices=["BUY", "SELL"],
        type=str.upper,
        help="Order side: BUY or SELL",
    )
    order.add_argument(
        "--type",
        dest="order_type",
        required=True,
        choices=["MARKET", "LIMIT", "STOP_MARKET"],
        type=str.upper,
        help="Order type: MARKET, LIMIT, or STOP_MARKET",
    )
    order.add_argument(
        "--quantity",
        required=True,
        help="Order quantity (e.g., 0.001)",
    )
    order.add_argument(
        "--price",
        default=None,
        help="Limit price — required for LIMIT orders",
    )
    order.add_argument(
        "--stop-price",
        default=None,
        dest="stop_price",
        help="Stop trigger price — required for STOP_MARKET orders",
    )
    order.add_argument(
        "--reduce-only",
        action="store_true",
        default=False,
        help="Only reduce an existing position",
    )

    # ── Misc ────────────────────────────────────────────────────────────
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        type=str.upper,
        help="Console log verbosity (default: INFO)",
    )
    parser.add_argument(
        "--json",
        dest="output_json",
        action="store_true",
        help="Output raw JSON result instead of formatted summary",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and print request summary without placing an order",
    )
    parser.add_argument(
        "--mock",
        action="store_true",
        help="Simulate order locally — no API keys or internet needed",
    )

    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    # ── Logging setup ───────────────────────────────────────────────────
    setup_logging(args.log_level)
    logger = get_logger("cli")

    # ── Credential check ────────────────────────────────────────────────
    if not args.mock and (not args.api_key or not args.api_secret):
        print(
            f"{RED}Error:{RESET} API key/secret not provided.\n"
            "Set environment variables BINANCE_API_KEY and BINANCE_API_SECRET,\n"
            "or pass --api-key and --api-secret on the command line.\n"
            f"{YELLOW}Tip:{RESET} Use --mock to simulate without any credentials.",
            file=sys.stderr,
        )
        return 1

    # ── Input validation ────────────────────────────────────────────────
    try:
        params = validate_order_params(
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
            stop_price=args.stop_price,
        )
    except ValueError as exc:
        print(f"{RED}Validation error:{RESET} {exc}", file=sys.stderr)
        logger.warning("Validation failed: %s", exc)
        return 1

    # ── Request summary ─────────────────────────────────────────────────
    request_display = {
        "Symbol": params["symbol"],
        "Side": params["side"],
        "Order Type": params["order_type"],
        "Quantity": params["quantity"],
        "Price": params["price"] if params["price"] else "N/A (MARKET)",
        "Stop Price": params["stop_price"] if params["stop_price"] else "N/A",
        "Reduce Only": args.reduce_only,
    }
    _print_section("ORDER REQUEST SUMMARY", request_display)

    if args.dry_run:
        print(f"\n{YELLOW}[DRY RUN] Order not placed.{RESET}")
        return 0

    # ── Place order ─────────────────────────────────────────────────────
    print(f"\n{CYAN}Submitting order to Binance Futures Testnet…{RESET}")

    try:
        client = BinanceClient(
            api_key=args.api_key or "MOCK_KEY",
            api_secret=args.api_secret or "MOCK_SECRET",
            mock=args.mock,
        )
    except ValueError as exc:
        print(f"{RED}Client init error:{RESET} {exc}", file=sys.stderr)
        return 1

    result = place_order(
        client=client,
        symbol=params["symbol"],
        side=params["side"],
        order_type=params["order_type"],
        quantity=params["quantity"],
        price=params["price"],
        stop_price=params["stop_price"],
        reduce_only=args.reduce_only,
    )

    # ── Output ──────────────────────────────────────────────────────────
    if args.output_json:
        # Serialise Decimals as strings for JSON
        def _default(obj):
            from decimal import Decimal
            if isinstance(obj, Decimal):
                return str(obj)
            raise TypeError

        print(json.dumps(result, indent=2, default=_default))
        return 0 if result["success"] else 1

    if result["success"]:
        summary = result["order_summary"]
        display = {
            "Order ID": summary.get("orderId"),
            "Status": summary.get("status"),
            "Symbol": summary.get("symbol"),
            "Side": summary.get("side"),
            "Type": summary.get("type"),
            "Orig Qty": summary.get("origQty"),
            "Executed Qty": summary.get("executedQty"),
            "Avg Price": summary.get("avgPrice") or "N/A",
            "Limit Price": summary.get("price") or "N/A",
            "Update Time": summary.get("updateTime"),
        }
        _print_section("ORDER RESPONSE", display)
        print(f"\n{GREEN}{BOLD}✔  Order placed successfully!{RESET}")
        if args.mock:
            print(f"{YELLOW}  [SIMULATION MODE — no real order was sent]{RESET}\n")
        else:
            print()
        return 0
    else:
        print(f"\n{RED}{BOLD}✘  Order failed:{RESET} {result['error']}\n", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
