# 🤖 Binance Futures Testnet Trading Bot

A clean, structured Python CLI application for placing orders on the **Binance USDT-M Futures Testnet**.  
Supports **MARKET**, **LIMIT**, and **STOP_MARKET** orders with full input validation, structured logging, and graceful error handling.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance REST client (HMAC-signed requests)
│   ├── orders.py          # Order placement + result formatting
│   ├── validators.py      # Input validation (raises ValueError on bad input)
│   └── logging_config.py  # Rotating file + console logging setup
├── cli.py                 # CLI entry point (argparse)
├── logs/
│   └── trading_bot.log    # Auto-created; rotates at 5 MB
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Register a Binance Futures Testnet Account

1. Visit [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Sign up / log in
3. Navigate to **API Management** → **Generate API Key**
4. Copy your **API Key** and **Secret Key**

### 2. Clone / Download the Project

```bash
git clone https://github.com/<your-username>/trading-bot.git
cd trading-bot
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

> Python 3.8+ required. No third-party Binance SDK needed — only `requests` and `colorama`.

### 4. Set API Credentials

**Option A — Environment Variables (recommended):**

```bash
# Linux / macOS
export BINANCE_API_KEY="your_api_key_here"
export BINANCE_API_SECRET="your_api_secret_here"

# Windows PowerShell
$env:BINANCE_API_KEY = "your_api_key_here"
$env:BINANCE_API_SECRET = "your_api_secret_here"
```

**Option B — Inline flags (not recommended for production):**

```bash
python cli.py --api-key YOUR_KEY --api-secret YOUR_SECRET ...
```

---

## How to Run

### Basic Syntax

```
python cli.py --symbol SYMBOL --side BUY|SELL --type ORDER_TYPE --quantity QTY [options]
```

### Place a MARKET Order

```bash
# Buy 0.001 BTC at market price
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

# Sell 0.01 ETH at market price
python cli.py --symbol ETHUSDT --side SELL --type MARKET --quantity 0.01
```

### Place a LIMIT Order

```bash
# Sell 0.001 BTC when price hits $70,000
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 70000

# Buy 0.01 ETH at $3,200
python cli.py --symbol ETHUSDT --side BUY --type LIMIT --quantity 0.01 --price 3200
```

### Place a STOP_MARKET Order (Bonus)

```bash
# Stop-loss: sell 0.001 BTC if price drops to $65,000
python cli.py --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --stop-price 65000
```

### Additional Flags

| Flag | Description |
|---|---|
| `--reduce-only` | Only reduce an existing position |
| `--log-level DEBUG` | Show full HTTP request/response in console |
| `--json` | Output raw JSON result (useful for scripting) |
| `--dry-run` | Validate inputs and show summary without placing order |

### Dry Run Example

```bash
python cli.py --symbol BTCUSDT --side BUY --type LIMIT --quantity 0.001 --price 95000 --dry-run
```

---

## Example Output

```
──────────────────────────────────────────────────
  ORDER REQUEST SUMMARY
──────────────────────────────────────────────────
  Symbol             BTCUSDT
  Side               BUY
  Order Type         MARKET
  Quantity           0.001
  Price              N/A (MARKET)
  Stop Price         N/A
  Reduce Only        False

Submitting order to Binance Futures Testnet…

──────────────────────────────────────────────────
  ORDER RESPONSE
──────────────────────────────────────────────────
  Order ID           4751823609
  Status             FILLED
  Symbol             BTCUSDT
  Side               BUY
  Type               MARKET
  Orig Qty           0.001
  Executed Qty       0.001
  Avg Price          67843.50
  Update Time        1748768924502

✔  Order placed successfully!
```

---

## Logging

All activity is logged to `logs/trading_bot.log` (created automatically).

- **Console**: INFO level and above (configurable via `--log-level`)
- **File**: DEBUG level and above — includes full API request params and response bodies
- **Rotation**: 5 MB per file, 3 backup files retained

Log format:
```
2025-06-01 09:12:04 | INFO     | bot.client           | BinanceClient initialised. base_url=https://testnet.binancefuture.com
2025-06-01 09:12:04 | DEBUG    | bot.client           | REQUEST  method=POST url=... params={...}
2025-06-01 09:12:04 | DEBUG    | bot.client           | RESPONSE status=200 body={...}
```

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| Missing/invalid input | `Validation error:` message printed; exit code 1 |
| LIMIT order without `--price` | Validation error before any API call |
| API error (e.g., insufficient margin) | `Order failed:` with Binance error code + message |
| Network timeout | `Request timed out` logged; exit code 1 |
| Missing credentials | Clear message pointing to env vars |

---

## Assumptions

- **Testnet only**: The base URL is hardcoded to `https://testnet.binancefuture.com`. For live trading, override `TESTNET_BASE_URL` in `bot/client.py` (and obtain proper credentials).
- **One-way position mode**: Orders use `positionSide=BOTH` (default). Hedge mode is not supported without code changes.
- **Quantity precision**: The bot does not auto-adjust to each symbol's `LOT_SIZE` filter. If you receive a precision error, round your quantity to the symbol's step size.
- **No persistence**: This bot is stateless — it places one order per invocation. Order tracking requires querying the Binance API separately.

---

## Dependencies

| Package | Purpose |
|---|---|
| `requests` | HTTP REST calls to Binance API |
| `colorama` | Cross-platform coloured terminal output |

No Binance SDK is used — all API interactions are raw signed HTTP requests for full transparency and control.
