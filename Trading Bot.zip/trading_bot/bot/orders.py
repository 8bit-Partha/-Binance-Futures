"""
Order placement logic.

Bridges validated CLI parameters → BinanceClient → formatted results.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Dict, Optional

from bot.client import BinanceClient
from bot.logging_config import get_logger

logger = get_logger("bot.orders")


def _decimal_to_str(value: Optional[Decimal]) -> Optional[str]:
    """Convert Decimal to a plain string without scientific notation."""
    if value is None:
        return None
    # Normalize removes trailing zeros; to_eng_string avoids 'E+' notation
    return format(value.normalize(), "f")


def place_order(
    client: BinanceClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: Decimal,
    price: Optional[Decimal] = None,
    stop_price: Optional[Decimal] = None,
    reduce_only: bool = False,
) -> Dict[str, Any]:
    """
    Place an order via the Binance client and return a structured result dict.

    Returns:
        {
            "success": bool,
            "request_summary": dict,    # what was sent
            "response": dict | None,    # raw Binance response on success
            "order_summary": dict | None, # extracted key fields
            "error": str | None,        # human-readable error on failure
        }
    """
    request_summary = {
        "symbol": symbol,
        "side": side,
        "order_type": order_type,
        "quantity": str(quantity),
        "price": str(price) if price else None,
        "stop_price": str(stop_price) if stop_price else None,
        "reduce_only": reduce_only,
    }

    logger.info("Order request summary: %s", request_summary)

    try:
        raw = client.place_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=_decimal_to_str(quantity),
            price=_decimal_to_str(price),
            stop_price=_decimal_to_str(stop_price),
            reduce_only=reduce_only,
        )
    except Exception as exc:
        logger.error("Order placement failed: %s", exc)
        return {
            "success": False,
            "request_summary": request_summary,
            "response": None,
            "order_summary": None,
            "error": str(exc),
        }

    order_summary = {
        "orderId": raw.get("orderId"),
        "status": raw.get("status"),
        "executedQty": raw.get("executedQty"),
        "avgPrice": raw.get("avgPrice"),
        "origQty": raw.get("origQty"),
        "price": raw.get("price"),
        "type": raw.get("type"),
        "side": raw.get("side"),
        "symbol": raw.get("symbol"),
        "updateTime": raw.get("updateTime"),
    }

    logger.info("Order summary: %s", order_summary)

    return {
        "success": True,
        "request_summary": request_summary,
        "response": raw,
        "order_summary": order_summary,
        "error": None,
    }
