"""
Input validation for trading bot CLI parameters.
All validation raises ValueError with a descriptive message on failure.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Optional


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_MARKET"}

# Binance minimums (conservative defaults; actual limits vary by symbol)
MIN_QUANTITY = Decimal("0.001")
MIN_PRICE = Decimal("0.01")


def validate_symbol(symbol: str) -> str:
    """Normalize and validate a trading symbol (e.g., BTCUSDT)."""
    symbol = symbol.strip().upper()
    if not symbol.isalnum():
        raise ValueError(
            f"Invalid symbol '{symbol}'. Symbols must be alphanumeric (e.g., BTCUSDT)."
        )
    if len(symbol) < 5 or len(symbol) > 12:
        raise ValueError(
            f"Invalid symbol '{symbol}'. Expected 5–12 characters (e.g., BTCUSDT)."
        )
    return symbol


def validate_side(side: str) -> str:
    """Validate order side (BUY or SELL)."""
    side = side.strip().upper()
    if side not in VALID_SIDES:
        raise ValueError(
            f"Invalid side '{side}'. Must be one of: {', '.join(sorted(VALID_SIDES))}."
        )
    return side


def validate_order_type(order_type: str) -> str:
    """Validate order type (MARKET, LIMIT, or STOP_MARKET)."""
    order_type = order_type.strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise ValueError(
            f"Invalid order type '{order_type}'. "
            f"Must be one of: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    return order_type


def validate_quantity(quantity: str | float) -> Decimal:
    """Validate and parse order quantity."""
    try:
        qty = Decimal(str(quantity))
    except InvalidOperation:
        raise ValueError(f"Invalid quantity '{quantity}'. Must be a positive number.")
    if qty <= 0:
        raise ValueError(f"Quantity must be greater than zero, got {qty}.")
    if qty < MIN_QUANTITY:
        raise ValueError(
            f"Quantity {qty} is below the minimum allowed ({MIN_QUANTITY})."
        )
    return qty


def validate_price(price: str | float | None) -> Optional[Decimal]:
    """Validate and parse limit price. Returns None if price is not provided."""
    if price is None:
        return None
    try:
        p = Decimal(str(price))
    except InvalidOperation:
        raise ValueError(f"Invalid price '{price}'. Must be a positive number.")
    if p <= 0:
        raise ValueError(f"Price must be greater than zero, got {p}.")
    if p < MIN_PRICE:
        raise ValueError(
            f"Price {p} is below the minimum allowed ({MIN_PRICE})."
        )
    return p


def validate_stop_price(stop_price: str | float | None) -> Optional[Decimal]:
    """Validate and parse stop price for STOP_MARKET orders."""
    return validate_price(stop_price)  # same rules


def validate_order_params(
    symbol: str,
    side: str,
    order_type: str,
    quantity: str | float,
    price: str | float | None = None,
    stop_price: str | float | None = None,
) -> dict:
    """
    Run all validations and return a clean params dict.

    Raises ValueError with a descriptive message for any invalid input.
    """
    validated = {
        "symbol": validate_symbol(symbol),
        "side": validate_side(side),
        "order_type": validate_order_type(order_type),
        "quantity": validate_quantity(quantity),
        "price": None,
        "stop_price": None,
    }

    otype = validated["order_type"]

    if otype == "LIMIT":
        if price is None:
            raise ValueError("Price is required for LIMIT orders.")
        validated["price"] = validate_price(price)

    if otype == "MARKET" and price is not None:
        raise ValueError("Price must not be provided for MARKET orders.")

    if otype == "STOP_MARKET":
        if stop_price is None:
            raise ValueError("--stop-price is required for STOP_MARKET orders.")
        validated["stop_price"] = validate_stop_price(stop_price)

    return validated
