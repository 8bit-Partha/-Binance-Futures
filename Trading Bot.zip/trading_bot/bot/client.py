"""
Binance Futures Testnet REST client.

Wraps raw HTTP calls (requests) to the Binance USDT-M Futures API.
All requests are signed with HMAC-SHA256. Responses are logged in full.

Pass mock=True to use simulation mode — no API keys or internet needed.
"""

from __future__ import annotations

import hashlib
import hmac
import random
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests

from bot.logging_config import get_logger

logger = get_logger("bot.client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_TIMEOUT = 10  # seconds

# Realistic mock prices per symbol
MOCK_PRICES = {
    "BTCUSDT": 67843.50,
    "ETHUSDT": 3521.75,
    "BNBUSDT": 412.30,
    "SOLUSDT": 178.90,
    "XRPUSDT": 0.6123,
}


class BinanceAPIError(Exception):
    """Raised when the Binance API returns an error payload."""

    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class BinanceClient:
    """
    Thin authenticated wrapper around the Binance Futures Testnet REST API.

    Args:
        api_key:    Your testnet API key (use any value in mock mode).
        api_secret: Your testnet API secret (use any value in mock mode).
        base_url:   Override the base URL.
        timeout:    HTTP request timeout in seconds.
        mock:       If True, simulate responses locally without any API calls.
    """

    def __init__(
        self,
        api_key: str = "MOCK_KEY",
        api_secret: str = "MOCK_SECRET",
        base_url: str = TESTNET_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        mock: bool = False,
    ):
        self._api_key = api_key
        self._api_secret = api_secret
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._mock = mock
        self._order_counter = random.randint(4_000_000_000, 4_900_000_000)

        if not mock:
            if not api_key or not api_secret:
                raise ValueError("api_key and api_secret must not be empty.")
            self._session = requests.Session()
            self._session.headers.update(
                {
                    "X-MBX-APIKEY": self._api_key,
                    "Content-Type": "application/x-www-form-urlencoded",
                }
            )

        mode = "SIMULATION" if mock else "LIVE"
        logger.info(
            "BinanceClient initialised. mode=%s base_url=%s", mode, self._base_url
        )

    # ------------------------------------------------------------------
    # Mock helpers
    # ------------------------------------------------------------------

    def _mock_order_response(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: str,
        price: Optional[str],
        stop_price: Optional[str],
        time_in_force: str,
    ) -> Dict[str, Any]:
        """Generate a realistic Binance order response dict."""
        self._order_counter += random.randint(1, 50)
        order_id = self._order_counter
        ts = int(time.time() * 1000)

        base_price = MOCK_PRICES.get(symbol, 100.0)
        # Add slight randomness to simulate live price
        simulated_price = round(base_price * random.uniform(0.998, 1.002), 2)

        if order_type == "MARKET":
            status = "FILLED"
            avg_price = str(simulated_price)
            exec_qty = quantity
            limit_price = "0"
        elif order_type == "LIMIT":
            status = "NEW"
            avg_price = "0"
            exec_qty = "0"
            limit_price = price or "0"
        else:  # STOP_MARKET
            status = "NEW"
            avg_price = "0"
            exec_qty = "0"
            limit_price = "0"

        return {
            "orderId": order_id,
            "symbol": symbol,
            "status": status,
            "clientOrderId": f"x-MockBot{random.randint(10000,99999)}",
            "price": limit_price,
            "avgPrice": avg_price,
            "origQty": quantity,
            "executedQty": exec_qty,
            "cumQty": exec_qty,
            "cumQuote": str(round(float(exec_qty) * simulated_price, 5))
            if exec_qty != "0"
            else "0",
            "timeInForce": time_in_force,
            "type": order_type,
            "reduceOnly": False,
            "closePosition": False,
            "side": side,
            "positionSide": "BOTH",
            "stopPrice": stop_price or "0",
            "workingType": "CONTRACT_PRICE",
            "priceProtect": False,
            "origType": order_type,
            "updateTime": ts,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _timestamp(self) -> int:
        return int(time.time() * 1000)

    def _sign(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Append HMAC-SHA256 signature to a params dict (in-place)."""
        query_string = urlencode(params)
        signature = hmac.new(
            self._api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        params["signature"] = signature
        return params

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = True,
    ) -> Dict[str, Any]:
        """Execute an HTTP request, log it, and return parsed JSON."""
        params = params or {}

        if signed:
            params["timestamp"] = self._timestamp()
            self._sign(params)

        url = f"{self._base_url}{endpoint}"
        log_params = {k: v for k, v in params.items() if k != "signature"}
        logger.debug(
            "REQUEST  method=%s url=%s params=%s", method.upper(), url, log_params
        )

        try:
            if method.upper() in ("GET", "DELETE"):
                response = self._session.request(
                    method, url, params=params, timeout=self._timeout
                )
            else:
                response = self._session.request(
                    method, url, data=params, timeout=self._timeout
                )
        except requests.exceptions.Timeout:
            logger.error("Request timed out: %s %s", method.upper(), url)
            raise
        except requests.exceptions.ConnectionError as exc:
            logger.error("Connection error: %s", exc)
            raise

        logger.debug(
            "RESPONSE status=%s body=%s", response.status_code, response.text[:2000]
        )

        try:
            data = response.json()
        except ValueError:
            response.raise_for_status()
            raise

        if isinstance(data, dict) and "code" in data and int(data["code"]) < 0:
            error = BinanceAPIError(int(data["code"]), data.get("msg", "Unknown error"))
            logger.error("API error: %s", error)
            raise error

        response.raise_for_status()
        return data

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: str,
        price: Optional[str] = None,
        stop_price: Optional[str] = None,
        time_in_force: str = "GTC",
        reduce_only: bool = False,
    ) -> Dict[str, Any]:
        """Place a new order (real or simulated depending on mock mode)."""
        logger.info(
            "Placing order: symbol=%s side=%s type=%s qty=%s price=%s stopPrice=%s",
            symbol, side, order_type, quantity, price, stop_price,
        )

        if self._mock:
            # Simulate a small network delay
            time.sleep(random.uniform(0.1, 0.3))
            params_log = {
                "symbol": symbol, "side": side, "type": order_type,
                "quantity": quantity, "timestamp": self._timestamp(),
            }
            if price:
                params_log["price"] = price
                params_log["timeInForce"] = time_in_force
            if stop_price:
                params_log["stopPrice"] = stop_price

            logger.debug(
                "REQUEST  method=POST url=%s/fapi/v1/order params=%s",
                self._base_url, params_log,
            )
            response = self._mock_order_response(
                symbol, side, order_type, quantity, price, stop_price, time_in_force
            )
            import json
            logger.debug(
                "RESPONSE status=200 body=%s", json.dumps(response)
            )
        else:
            params: Dict[str, Any] = {
                "symbol": symbol, "side": side,
                "type": order_type, "quantity": quantity,
            }
            if order_type == "LIMIT":
                if price is None:
                    raise ValueError("price is required for LIMIT orders")
                params["price"] = price
                params["timeInForce"] = time_in_force
            if order_type == "STOP_MARKET":
                if stop_price is None:
                    raise ValueError("stop_price is required for STOP_MARKET orders")
                params["stopPrice"] = stop_price
            if reduce_only:
                params["reduceOnly"] = "true"
            response = self._request("POST", "/fapi/v1/order", params=params)

        logger.info(
            "Order placed successfully: orderId=%s status=%s",
            response.get("orderId"), response.get("status"),
        )
        return response

    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        params = {"symbol": symbol, "orderId": order_id}
        logger.info("Cancelling order: symbol=%s orderId=%s", symbol, order_id)
        return self._request("DELETE", "/fapi/v1/order", params=params)

    def get_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        params = {"symbol": symbol, "orderId": order_id}
        return self._request("GET", "/fapi/v1/order", params=params)
